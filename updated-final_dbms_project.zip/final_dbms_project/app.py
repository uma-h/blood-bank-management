from flask import Flask, render_template, redirect, flash, url_for, session, request, logging
import psycopg2
from datetime import date


app=Flask(__name__)

con=psycopg2.connect(dbname='bbm3',user='postgres')
cur=con.cursor()

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')




@app.route('/userlogin',methods=['GET','POST'])
def userlogin():
    if request.method=='POST':
       
        password = request.form['password']
        username = request.form['usertype']

        if username=='donar' and password =='5678':
            return render_template('donar_dashboard.html')
        elif username=='users' and password =='9011':
            return render_template('patient.html')
        elif username=='admin' and password =='1234':
            return render_template('admin_dashboard.html')
        elif username=='camp_Organizer' and password=='1213':
             return render_template('camps.html')
        else:
             return render_template('error.html')
    return render_template('userlogin.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    cur.execute("select * from bloodgroup order by blood_grp" )
    details= cur.fetchall() 
    print(details)
    Aneg=(details[0][1])
    Apos=(details[1][1])
    ABneg=(details[2][1])
    ABpos=(details[3][1])
    Bneg=(details[4][1])
    Bpos=(details[5][1])
    Oneg=(details[6][1])
    Opos=(details[7][1])
    cur.execute("select sum(no_of_packets) from bloodgroup" )
    count=cur.fetchone()
    cur.execute("select count(query_id) from patient")
    qcount=cur.fetchone()
    cur.execute("select count(query_id) from patient where status='approved'")
    appcount=cur.fetchone()
    cur.execute("select  count(distinct don_id) from blood;")
    dcount=cur.fetchone()
    return render_template('admin_dashboard.html',A_neg=Aneg,A_pos=Apos,AB_neg=ABneg,AB_pos=ABpos,B_neg=Bneg,B_pos=Bpos,O_neg=Oneg,O_pos=Opos,total=count,q_count=qcount,app_count=appcount,don_count=dcount)

@app.route('/admin_donar')
def admin_donar():
    cur.execute("select * from donar")
    details = cur.fetchall() 
    if len(details)>0:
        return render_template('admin_donar.html',details=details)
    return render_template('admin_donar.html',details=details)
   
@app.route('/admin_donation')
def admin_donation():
   return render_template('admin_donation.html')

@app.route('/approved_page/<p_id>/<blood_grp>')
def approved_page(p_id,blood_grp):
   cur.execute("select blood_id,don_id from blood where blood_grp=%s and p_id is NULL",(blood_grp,))
   d=cur.fetchone()
   print(d[0])
   cur.execute("update blood set p_id=%s where blood_id=%s",(p_id,d[0]))
   cur.execute("update patient set status='approved',do_id=%s where p_id=%s",(d[1],p_id))
   con.commit()
   return render_template('approved_page.html')

@app.route('/admin_patient')
def admin_patient():
    cur.execute("select p_name,hospital_id,query_blood_grp,req_blood_vol_ml,status from patient order by status")
    details = cur.fetchall() 
    return render_template('admin_patient.html',details=details)
@app.route('/admin_donate_blood')
def admin_donate_blood():
    cur.execute("select p_name,hospital_id,query_blood_grp,req_blood_vol_ml,status,p_id from patient where status='pending' order by status")
    details = cur.fetchall() 
    return render_template('admin_donate_blood.html',details=details)
@app.route('/admin_request_history')
def admin_request_history():
    cur.execute("select p.p_id, p.p_name, d.d_name,query_blood_grp, query_date from patient as p, donar as d where d.donar_id = p.do_id and p.status='approved'")
    admin_req_hist = cur.fetchall()
    return render_template('admin_request_history.html' , admin_req_hist = admin_req_hist)
@app.route('/donar_details')
def donar_details():
    return render_template('donar_details.html')

@app.route('/admin_request')
def admin_request():
    cur.execute("select p.p_id, p.p_name, d.d_name,p.query_blood_grp, p.query_date from patient as p, donar as d where d.donar_id = p.do_id and p.status='pending'")
    adminreq = cur.fetchall()
    # print(adminreq[0])
    return render_template('admin_request.html' , adminreq = adminreq)

@app.route('/update_donar/<id>',methods=['GET','POST'])
def update_donar(id):
    if request.method  == 'POST':
        # Get Form Fields
        dname = request.form["d_name"]
        age = request.form["d_age"]
        address = request.form["d_address"]
        demail = request.form["d_email"]
        blood_grp = request.form["blood_grp"]
        cur.execute("update donar set d_name=%s,d_address=%s,d_age=%s,d_email=%s,d_blood_grp=%s where donar_id=%s" ,(dname,address,age,demail,blood_grp,id))
        con.commit()
        #close connection
        flash('Success! Donor details updated.','success')
        #return redirect(url_for('donor_dashboard'))'''
    return render_template('update_donar.html')



@app.route('/viewCamps')
def viewcamps():
    cur.execute("select c_date,camp_id,camp_location,bank_name,b_ph,b_location from camp,blood_bank where c_date< 'today' and blood_bank_id=bank_code;")
    
    details = cur.fetchall()
    
    if len(details)>0:
        return render_template('viewCamps.html',details=details)
    else:
         msg = ' Blood Bank is Empty '
         return render_template('viewcamps.html',msg=msg)
@app.route('/upcomingcamps')
def upcomingcamps():
    cur.execute("select c_date,camp_id,camp_location,bank_name,b_ph,b_location from camp,blood_bank where c_date>= 'today' and blood_bank_id=bank_code;")
    
    details = cur.fetchall()
    
    if len(details)>0:
        return render_template('viewCamps.html',details=details)
    else:
         msg = ' Blood Bank is Empty '
         return render_template('viewcamps.html',msg=msg)

    #close connection
@app.route('/bank_camp')
def bank_camps():
    cur.execute("select bank_name,bank_code,count(camp_id)as no_of_camp_organized from Blood_bank left outer join camp on  blood_bank_id=bank_code and c_date>'today' group by bank_code order by no_of_camp_organized desc;")
    
    details = cur.fetchall()
    
    if len(details)>0:
        return render_template('bank_camp.html',details=details)
    else:
         msg = ' Blood Bank is Empty '
         return render_template('bank_camp.html',msg=msg)

    #close connection
@app.route('/donarlist' ,methods=['GET','POST'])
def donarlist():
    cur.execute("SELECT * from donar")
    
    details = cur.fetchall()
    
    if len(details)>0:
        return render_template('donarlist.html',details=details)
    else:
         msg = ' Blood Bank is Empty '
         return render_template('donarlist.html',msg=msg)


@app.route('/donar_register',methods=['GET','POST'])
def donar_dashboard():
    if request.method  == 'POST':
        # Get Form Fields
        dname = request.form["d_name"]
        age = request.form["d_age"]
        address = request.form["d_address"]
        demail = request.form["d_email"]
        blood_grp = request.form["blood_grp"]
        campid=request.form["campid"]
        
        #create a cursor
        #cur=con.cursor()

        #Inserting values into tables
        cur.execute("INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid) VALUES(%s, %s, %s, %s, %s, %s)",(dname,address,age,demail,blood_grp,campid))
        #Commit to DB
        con.commit()
        #close connection
        flash('Success! Donor details Added.','success')
        #return redirect(url_for('donor_dashboard'))

    return render_template('donar_register.html')


@app.route('/add_donar_camp',methods=['GET','POST'])
def add_donar_camp():
    if request.method  == 'POST':
        dname = request.form["d_name"]
        blood_grp = request.form["blood_grp"]
        blood_vol = request.form["blood_vol_ml"]
        
        
        
        cur.execute("select donar_id,cid,blood_bank_id from donar,camp where d_name=%s and d_blood_grp=%s and cid=camp_id",(dname,blood_grp))
        detail=cur.fetchall()
        print(detail)
        if len(detail)>0:
            cur.execute("insert into blood (bank_id,blood_vol_ml,blood_grp,don_id) VALUES(%s, %s, %s, %s)",(detail[2],blood_vol,blood_grp,detail[0]))
            con.commit()
            flash('Success! Donor details Added.','success')

        else:
             msg = 'record not found'
             return render_template('add_donar_camp.html',msg=msg)
       

    return render_template('add_donar_camp.html')

@app.route('/patient',methods=['GET','POST'])
def patient():
    if request.method  == 'POST':
            query_blood_grp = request.form["query_blood_grp"]
            p_name = request.form["p_name"]
            hospital_id = request.form["hospital_id"]
            req_blood_vol_ml = request.form["req_blood_vol_ml"]
            cur.execute("INSERT INTO Patient(p_name,hospital_id,query_blood_grp,req_blood_vol_ml) VALUES(%s, %s, %s, %s)",(p_name,hospital_id,query_blood_grp,req_blood_vol_ml))
            con.commit()
            #print("working")
            cur.execute("select d_name,d_email from donar where d_blood_grp in(select c from compatible where blood_grp = %s)",(query_blood_grp,))
            mb_grps = cur.fetchall()
            if len(mb_grps)>0:
                return render_template('donar_details.html',mb_grps=mb_grps)
            else:
                msg = ' Matching blood stock not available '
                return render_template('donar_details.html',msg=msg)
    return render_template('patient.html')
@app.route('/banknearme',methods=['GET','POST'])
def banknearme():
    if request.method == 'POST':
        print("came till here")
        banksnearme = request.form["banknearme"]
        bank_near_me = '%'+ banksnearme +'%'
        cur.execute("select bbb.branch_code, bbb.bbaddress, bb.bank_name from blood_bank as bb, blood_bank_branch as bbb where bbb.bbaddress like %s and bb.bank_code = bbb.bank_id",(bank_near_me,))
        banks_nm = cur.fetchall()
        if len(banks_nm)>0:
           return render_template('displaybank.html',banks_nm=banks_nm)
        else:
            msg = 'No blood banks available near you'
            return render_template('displaybank.html',msg=msg)
    return render_template('banknearme.html')

@app.route('/displaybank')
def displaybank():
    return render_template('displaybank.html')

@app.route('/patient')
def camp():
     return render_template('patient.html')

@app.route('/logout')
def logout():
    return render_template('logout.html')

if __name__=='__main__':
    app.secret_key='some secret key'
    app.config['SESSION_TYPE']='filesystem'
    app.run(debug=True)