\c bbm5;
create table bloodGROUP(blood_grp char(6),no_of_packets int);
create or replace function increment()
returns trigger as $$
BEGIN
update bloodgroup set no_of_packets=no_of_packets+new.blood_vol_ml where blood_grp=new.blood_grp;
return new;end;$$ Language plpgsql;


create trigger new_blood
after insert on blood 
for each row 
execute procedure increment();

insert into bloodgroup values('A+',0);
insert into bloodgroup values('A-',0);
insert into bloodgroup values('B+',0);
insert into bloodgroup values('B-',0);
insert into bloodgroup values('AB+',0);
insert into bloodgroup values('AB-',0);
insert into bloodgroup values('O+',0);
insert into bloodgroup values('O-',0);

create or replace function decrement()
returns trigger as $$
BEGIN
update bloodgroup set no_of_packets=no_of_packets-old.blood_vol_ml where blood_grp=old.blood_grp;
return new;end;$$ Language plpgsql;


create trigger lost_blood
after update of p_id on blood 
for each row 
execute procedure decrement();