drop database bbm3;
create database bbm3;
--donar age added.
\c bbm5;
CREATE TABLE Donar
(	d_name VARCHAR(25) NOT NULL , 
	d_Address VARCHAR(45),
	d_age INT DEFAULT NULL,
	d_email VARCHAR(35) NOT NULL, 
	donar_id SERIAL PRIMARY KEY,
	d_blood_grp CHAR(6),	
	cid INT NOT NULL
);

CREATE TABLE Patient
(	p_name VARCHAR(25) NOT NULL , 
	hospital_id CHAR(15) NOT NULL,
	p_id SERIAL ,
	query_id SERIAL NOT NULL UNIQUE,
	query_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	query_blood_grp CHAR(3),
	req_blood_vol_ml INT NOT NULL,
	status VARCHAR(10) default 'Pending',
	pay_id INT DEFAULT NULL,
	pay_date DATE DEFAULT NULL, 
	pay_mode VARCHAR(10) DEFAULT NULL,
	blood_cost INT DEFAULT NULL,   		 
	do_id INT DEFAULT NULL,
	PRIMARY KEY (p_id),
	FOREIGN KEY (do_id) REFERENCES Donar(donar_id) ON UPDATE CASCADE
);
CREATE TABLE Blood_bank
(	bank_name VARCHAR(40) NOT NULL , 
	bank_code CHAR(15) NOT NULL, 
	manager VARCHAR(25) NOT NULL, 
	b_ph BIGINT,    
	b_email VARCHAR(30) NOT NULL,
	b_location VARCHAR(80),
	PRIMARY KEY (bank_code)
);
CREATE TABLE Camp
(
	c_date DATE, 		
	camp_id SERIAL,
	camp_location VARCHAR(40),
	blood_bank_id CHAR(15) NOT NULL,
	PRIMARY KEY(camp_id),
	FOREIGN KEY(blood_bank_id) REFERENCES Blood_bank(bank_code) ON DELETE SET NULL
);


CREATE TABLE Blood_bank_branch
(
	branch_manager VARCHAR(25) NOT NULL,
	branch_code CHAR(15) NOT NULL,
	bbph BIGINT,
	bbaddress VARCHAR(80) UNIQUE,
	branch_email VARCHAR(30) NOT NULL,
	bank_id CHAR(15) NOT NULL,
	PRIMARY KEY(branch_code),
	FOREIGN KEY(bank_id) REFERENCES Blood_bank(bank_code) ON UPDATE CASCADE
);

CREATE TABLE Health
(
	donar_id SERIAL,
	alcohol CHAR(5),
	sugar_level VARCHAR(10),
	cancer CHAR(5),
	HIV CHAR(5),
	blood_level INT,
	anemia CHAR(5),
	PRIMARY KEY(donar_id),
	FOREIGN KEY(donar_id) REFERENCES Donar(donar_id)
);

CREATE TABLE Blood
(
	bank_id CHAR(15) NOT NULL,
	blood_id SERIAL,
	blood_vol_ml INT NOT NULL,
	blood_grp CHAR(3),
	p_id INT DEFAULT NULL,
	don_id INT,
	PRIMARY KEY(blood_id),
	FOREIGN KEY(bank_id) REFERENCES Blood_bank(bank_code),
	FOREIGN KEY(don_id) REFERENCES Donar(donar_id) ON DELETE SET NULL
	
);
CREATE TABLE Compatible
(
	blood_grp VARCHAR(3),
	c VARCHAR(3)
);