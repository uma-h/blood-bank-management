\c bbm3;
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values('Suchitra','shankar colony',15,'suchitra12@gmail.com','B+',1);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values('akash','HSR layout',16,'akash12@gmail.com','B+',2);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values('sharan','JP nagar',20,'sharan12@gmail.com','AB+',2);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values('rajesh','basavangudi',21,'raju0912@gmail.com', 'AB-',1);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values('Santhosh', 'chickpet', 22,'santhu12@gmail.com', 'B-', 3);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values('venkat', 'jayanagar 4th block',24, 'vekatesh12@gmail.com', 'O-', 1);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values ('Shreya', 'mysore road', 26,'shreyaaah1@gmail.com', 'O+', 3);
INSERT into Donar (d_name, d_Address,d_age, d_email, d_blood_grp,cid)
values ('Shreyas', 'majestic', 24,'shre124yas@gmail.com', 'O+', 3);

INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status,pay_id,pay_date,pay_mode,blood_cost,do_id)
values ('Anusha', 'HOS00100' ,'2021-10-12', 'B+' ,2,'approved',1,'2021-10-12','online',3200,1);
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status,pay_id,pay_date,pay_mode,blood_cost,do_id)
values( 'Neha', 'HOS00201'  ,'2021-10-09', 'B+' ,2,'approved',2,'2021-10-10','online',4000,5);
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status,pay_id,pay_date,pay_mode,blood_cost,do_id)  
values('Suman', 'HOS00123'  ,'2021-10-05', 'AB+' ,2,'approved',3,'2021-10-8','offline',500,4);
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status,pay_id,pay_date,pay_mode,blood_cost,do_id)
values('Akhil', 'HOS00203'  ,'2021-10-06', 'O+' ,2,'approved',4,'2021-10-8','online',3400,7);
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status)
values('Salini', 'HOS00222'  ,'2021-10-15', 'O-' ,2,'pending');
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status) 
values('Swetha', 'HOS00120'  ,'2021-10-12', 'B+' ,2,'pending');
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status,pay_id,pay_date,pay_mode,blood_cost,do_id)  
values('aveena', 'HOS00401' ,'2021-10-11', 'B-' ,2,'approved',6,'2021-10-12','online',1000,3);
INSERT into Patient (p_name, hospital_id, query_date, query_blood_grp, req_blood_vol_ml, status,pay_id,pay_date,pay_mode,blood_cost,do_id)  
values('varun', 'HOS00250'  ,'2021-10-10', 'B+' ,2,'approved',7,'2021-10-12','offline',2000,2);

INSERT into Blood_bank  values('sanjeevini Blood center', 'bank01' , 'Harish' ,6967419809,'sanjeevini@gmail.com','Netaji Subhash Road, kolkata-700001, West Bengal');
INSERT into Blood_bank  values('rotary', 'bank08' , 'sohan' ,8127419409,'rotatryblood@gmail.com','Bandra kurla complex, Bandra(East), Mumbai 400 051');
INSERT into Blood_bank  values('Hapse Blood bank', 'bank02' , 'Vinay' ,6964759809,'Hapse@gmail.com','head office, Dr. Pattabhi Bhavan, saifabad, Hyderabad 500 004');
INSERT into Blood_bank  values('Reynolds Blood bank', 'bank03' , 'Arvind' ,9737419809,'reyno@gmail.com','Lokmangal 1501, Shivajinagar, Pune');
INSERT into Blood_bank  values('Arpan Blood Center', 'bank04' , 'Likith' ,8967419666,'arpanosave@gmail.com','Head office, JC road, Bangalore - 560002');
INSERT into Blood_bank  values('Shakthi Blood center', 'bank05' , 'Varun' ,7047419809,'shakthidonate@gmail.com','Head office, 66, Rajaji Salai, Chennai - 600 002');
INSERT into Blood_bank  values('Jankalyan Blood center', 'bank06' , 'Vamshi' ,8946779851,'jankalyana@gmail.com','Head office, MG road, Bangalore 560 001');
INSERT into Blood_bank  values('Pravara Medical Trust Blood Bank', 'bank07' , 'Harsh' ,7676779834,'paravaratrust08@gmail.com','chandra Mukhi, Nariman Point, Mumbai 400 021');
INSERT into Blood_bank  values('Apollo', 'bank09' , 'Harish' ,6967419899,'apollo@gmail.com','Netaji Subhash Road, kolkata-700001, West Bengal');
INSERT into Blood_bank  values('heartcare Blood center', 'bank10' , 'Harish' ,6944419809,'heartcare@gmail.com','Netaji Subhash Road, kolkata-700001, West Bengal');

INSERT INTO  Camp (c_date, camp_location, blood_bank_id)
values('2021-10-14','PES college, hosakerehalli', 'bank02');
INSERT INTO  Camp (c_date, camp_location, blood_bank_id)
values('2021-11-16','gupta college, kathriguppe', 'bank05');
INSERT INTO  Camp (c_date, camp_location, blood_bank_id) 
values('2021-12-28','apollo hospital, vijaynagar', 'bank01');
INSERT INTO  Camp (c_date, camp_location, blood_bank_id)
values('2021-11-23','peter school, banashankari 3rd stage', 'bank01');
INSERT INTO  Camp (c_date, camp_location, blood_bank_id)
values('2021-10-09','hrudayalaya hospital,gandhi nagari', 'bank04');
INSERT INTO  Camp (c_date, camp_location, blood_bank_id)
values('2021-12-05','bugle park,basavanagudi', 'bank04');
INSERT INTO  Camp (c_date, camp_location, blood_bank_id)
values( '2021-11-18','district health care center', 'bank03');

INSERT INTO Blood_bank_branch  values('Ramesh', 'BB01',6966758543,'Malleshwaram','union@1234','bank01' );
INSERT INTO Blood_bank_branch  values('Govind', 'BB03',7023456790,'Koramangala','govind@1234','bank06' );
INSERT INTO Blood_bank_branch  values('Ramadevi', 'BB05',8197222789,'bididi','ramadevi@1234','bank06' );
INSERT INTO Blood_bank_branch  values('Sunitha', 'BB09',6966798756,'indiranagar','sunitha@1234','bank01' );
INSERT INTO Blood_bank_branch  values('Basaveshwar', 'BB20',8796543210,'Marathahalli','basu@1234','bank02' );
INSERT INTO Blood_bank_branch  values('Bavani', 'BB78',6976890345,'Yalahanka','bava@1234','bank04' );
INSERT INTO Blood_bank_branch  values('Ambika', 'BB23',6965678903,'sadhashivanagar','ambi@1234','bank07' );

Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia)
values('no','normal','no','no',4,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia)
values('no','normal','no','no',3,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia)
values('no','normal','no','yes',3,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia) 
values('no','normal','no','no',4,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia) 
values('no','normal','no','no',3,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia) 
values('no','normal','no','no',4,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia)
values('no','normal','no','no',4,'no');
Insert INTO Health (alcohol, sugar_level,cancer,HIV,blood_level,anemia)
values('yes','normal','no','yes',4,'no');

insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank02', 2, 'B+',NULL,1);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id) 
values('bank05',  2, 'B+',NULL,2);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank05', 2, 'AB+',NULL,3);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank02',  2, 'B-',NULL,4);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank01',  2, 'B-',NULL,5);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank02',  2, 'O-',NULL,6);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank01', 2, 'O+',NULL,7);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank01', 2, 'O+',NULL,7);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank01',  2, 'O+',NULL,7);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank05',  2, 'B+',NULL,2);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank01',  2, 'B-',NULL,5);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank02',  2, 'AB-',NULL,4);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank02',  2, 'O-',NULL,6);
insert into blood (bank_id,blood_vol_ml,blood_grp,p_id,don_id)
values('bank02',  2, 'O-',NULL,6);

INSERT INTO Compatible VALUES('A+','A+');
INSERT INTO Compatible VALUES('A+','A-');
INSERT INTO Compatible VALUES('A+','O+');
INSERT INTO Compatible VALUES('A+','O-');
INSERT INTO Compatible VALUES('B+','B+');
INSERT INTO Compatible VALUES('B+','B-');
INSERT INTO Compatible VALUES('B+','O+');
INSERT INTO Compatible VALUES('B+','O-');
INSERT INTO Compatible VALUES('A-','A-');
INSERT INTO Compatible VALUES('A-','O-');
INSERT INTO Compatible VALUES('B-','B-');
INSERT INTO Compatible VALUES('B-','O-');
INSERT INTO Compatible VALUES('O+','O+');
INSERT INTO Compatible VALUES('O+','O-');
INSERT INTO Compatible VALUES('O-','O-');
INSERT INTO Compatible VALUES('AB+','AB+');
INSERT INTO Compatible VALUES('AB+','AB-');
INSERT INTO Compatible VALUES('AB+','A+');
INSERT INTO Compatible VALUES('AB+','B+');
INSERT INTO Compatible VALUES('AB+','O+');
INSERT INTO Compatible VALUES('AB+','A-');
INSERT INTO Compatible VALUES('AB+','B-');
INSERT INTO Compatible VALUES('AB+','O-');
INSERT INTO Compatible VALUES('AB-','AB-');
    INSERT INTO Compatible VALUES('AB-','A-');
    INSERT INTO Compatible VALUES('AB-','B-');
    INSERT INTO Compatible VALUES('AB-','O-');
ALTER TABLE Donar ADD CONSTRAINT fkdonarcamp FOREIGN KEY(cid) REFERENCES Camp(camp_id);

update blood set p_id=1 where blood_id=1;
update blood set p_id=2 where blood_id=2;
update blood set p_id=3 where blood_id=3;
update blood set p_id=7 where blood_id=4;
update blood set p_id=8 where blood_id=5;
update blood set p_id=7 where blood_id=6;
update blood set p_id=4 where blood_id=8;

